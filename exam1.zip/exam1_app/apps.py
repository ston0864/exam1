from django.apps import AppConfig


class Exam1AppConfig(AppConfig):
    name = 'exam1_app'
